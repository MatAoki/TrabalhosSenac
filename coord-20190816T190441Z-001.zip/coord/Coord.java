
package coord;

import java.util.Scanner;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;


/**
 *
 * @author Matheus
 */
public class Coord {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        
        //Inicia o Scanner
        Scanner Read = new Scanner(System.in);
        
        // Classe abre um arquivo para leitura
        // mas so consigo ler o arquivo byte a byte
        FileReader arquivo = new FileReader("coordenadas.txt");
        // Classe permite fazer a leitura bufferizada do arquivo
        // ou seja, consigo ler uma linha inteiro do arquivo, e retorna
        // uma string
        BufferedReader bufferArquivo = new BufferedReader(arquivo);
        String coordArm;
        System.out.println("arquivo aberto corretamente");
        
        // le uma linha e armazena o número de coordenadas
        coordArm = bufferArquivo.readLine();
        System.out.println(coordArm);
        int cordArm = Integer.parseInt(coordArm);
                
        //Strings para leitura do arquivo de coordenadas
        String linha;
        String linhas [];
        
        //Array para armazenar as coordenadas do arquivo como números
        Ponto[] XY = new Ponto[cordArm];
        int x, y;
        
        //Loop para armazenar os as coordenadas na matriz
        for (int i = 0; i < cordArm; i++) {
            
            // le a segunda linha do arquivo
            linha = bufferArquivo.readLine();
            
            // converte a linha lida para
            // um vetor de string em função dos
            // espacos entre os numeros
            linhas = linha.split(" ");
            //converte de string para int e armazena
            x = Integer.parseInt(linhas[0]);
            y = Integer.parseInt(linhas[1]);
            
            XY[i] = new Ponto(x,y);
            
            //printa todos os vetores lidos e armazenados em ordem
            System.out.println(XY[i].getPonto()+" ");
        }
        
        //variável para pegar o número de pontos a serem mostrados
        int k;
        double D;
        
        System.out.println ("Digite a coordenada X do ponto: ");
        x = Read.nextInt();
        System.out.println ("Digite a coordenada Y do ponto: ");
        y = Read.nextInt();
        System.out.println ("Digite a quantidade de pontos a se comparar: ");
        k = Read.nextInt();
        
        //Armazena ponto do usuário e o instancia 
        Ponto pontoUser;
        pontoUser = new Ponto(x,y);
        System.out.println(pontoUser.getPonto()+" ");
        
        //double distXY[] = null;
        
        System.out.println("Distancias: ");
        System.out.println(" ");
        //Calcula distâncias de todos os Pontos em relação ao ponto do usuário
        for (int i = 0; i < cordArm; i++) {
            
            XY[i].D = XY[i].calcDist(pontoUser);
            System.out.println(XY[i].D); 
            //distXY[i] = XY[i].D;
        }
        
        //Encontra os K pontos com menor distância e printa
        System.out.println(" ");
        for (int i = 0; i < cordArm; i++) {
            
            double menorDist;
            menorDist = XY[i].D;
            String pontoPrint = null;
            
            for (int j = 0; j < cordArm; j++) {
                
                if (XY[i].D <= XY[j].D){
                    menorDist = XY[i].D;
                    pontoPrint = XY[i].getPonto();
                }
                
                else if (XY[j].D < XY[i].D){
                    menorDist = XY[j].D;
                    pontoPrint = XY[j].getPonto();
                }
                
            }
            
            if (k-1 >= i){
                System.out.print("Ponto: ");
                System.out.println(pontoPrint);
                System.out.print("Distancia: ");
                System.out.println(menorDist);
            }
        
        }
        

    }
    
    
    
    
    
}
