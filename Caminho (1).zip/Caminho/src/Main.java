
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Main {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        
        FileReader arquivo = new FileReader("labirinto.txt");
        
        BufferedReader bufferArquivo = new BufferedReader(arquivo);
        String linhas;
        System.out.println("arquivo aberto corretamente");
        
        // le uma linha e armazena o número de coordenadas
        linhas = bufferArquivo.readLine();
        System.out.println(linhas);
        int numLinhas = Integer.parseInt(linhas);
        
        //declara variaveis para ler e atribuir dados do arquivo txt
        String linhaArq;
        String linhasArq [];
        int state;
        
        //cria matriz e fila que vao ser utilizadas
        Labirinto[][] lab = new Labirinto [numLinhas][numLinhas];
        Fila F = new Fila(lab);
        
        for (int i = 0; i < numLinhas; i++) {
            
            // le a segunda linha do arquivo
            linhaArq = bufferArquivo.readLine();
            
            // converte a linha lida para
            // um vetor de string em função dos
            // espacos entre os numeros
            linhasArq = linhaArq.split(" ");
            
            //preenche todos os pontos com susas coordenadas e seus estados
            for (int j = 0; j < linhasArq.length; j++) {
                
                state = Integer.parseInt(linhasArq[j]);
                lab[i][j] = new Labirinto(i, j, state);
                //se for = a -2 (ponto inicial) ja o adiciona na fila
                if (lab[i][j].getState() == -2)
                    F.enqueueInicial(lab[i][j]);
            
            }
            
        }
        
        
        //printa arquivo lido
        printa(lab, numLinhas);
        
        //roda por toda a matriz para usando a fila
        while(!F.isEmpty()){
            //verifica se o ponto a esquerda e valido e o adiciona na fila
            if (F.atual().getX()-1 >= 0 ){
                //verifica se o state do ponto que vai ser adicionado e 0 para nao sobreescrever paredes nem outros pontos
                if(lab[F.atual().getY()][F.atual().getX()-1].getState()==0){
                    //verifica se o state do ponto atual e 0, se for, atribui ao ponto que vai ser adicionado
                    if (F.atual().getState() >0)
                        lab[F.atual().getY()][F.atual().getX()-1].setState(F.atual().getState());
                    //adiciona na fila e soma o state
                    F.enqueue(lab[F.atual().getY()][F.atual().getX()-1]);
                }
            }
            //verifica se o ponto a direita e valido e o adiciona na fila igual ao primeiro
            if (F.atual().getX()+1 < numLinhas){
                if(lab[F.atual().getY()][F.atual().getX()+1].getState()==0){
                    if (F.atual().getState() >0)
                        lab[F.atual().getY()][F.atual().getX()+1].setState(F.atual().getState());
                    F.enqueue(lab[F.atual().getY()][F.atual().getX()+1]);
                }
            }
            //verifica se o ponto de baixo e valido e o adiciona na fila igual ao primeiro
            if (F.atual().getY()-1 >= 0){
                if(lab[F.atual().getY()-1][F.atual().getX()].getState()==0){
                    if (F.atual().getState() >0)
                        lab[F.atual().getY()-1][F.atual().getX()].setState(F.atual().getState());
                    F.enqueue(lab[F.atual().getY()-1][F.atual().getX()]);
                }
            }
            //verifica se o ponto de cima e valido e o adiciona na fila igual ao primeiro
            if (F.atual().getY()+1 < numLinhas){
                if(lab[F.atual().getY()+1][F.atual().getX()].getState()==0){
                    if (F.atual().getState() >0)
                        lab[F.atual().getY()+1][F.atual().getX()].setState(F.atual().getState());
                    F.enqueue(lab[F.atual().getY()+1][F.atual().getX()]);
                }
            }
            //retira o ponto atual da fila
            F.dequeue();
            
            
                   
        }
        // printa iteracao
        printa(lab, numLinhas);
        
        Fila theWay = new Fila(lab);
        //define partida pelo ponto B para armazenar caminho mais curto
        for (int i = 0; i < numLinhas; i++) {
            for (int j = 0; j < numLinhas; j++) {
                if (lab[i][j].getState() == -3)
                    theWay.enqueueInicial(lab[i][j]);
            }
        }
        
        //armazena pontos do caminho mais curto
        //Labirinto[] theWayLab = new Labirinto [numLinhas*numLinhas];
        int s1 = 2000;
        int s2 = 2000;
        int s3 = 2000;
        int s4 = 2000;
        
        while(!theWay.isEmpty()){
            
            if (theWay.atual().getX()-1 >= 0 )
                if (lab[theWay.atual().getY()][theWay.atual().getX()-1].getState()>0)
                    s1 = lab[theWay.atual().getY()][theWay.atual().getX()-1].getState();
            else 
                s1 = 2000;
                
            if (theWay.atual().getX()+1 < numLinhas )
                if (lab[theWay.atual().getY()][theWay.atual().getX()+1].getState()>0)
                    s2 = lab[theWay.atual().getY()][theWay.atual().getX()+1].getState();
            else 
                s2 = 2000;
            
            if (theWay.atual().getY()-1 >= 0 )
                if(lab[theWay.atual().getY()-1][theWay.atual().getX()].getState()>0)
                    s3 = lab[theWay.atual().getY()-1][theWay.atual().getX()].getState();
            else 
                s3 = 2000;
            
            if (theWay.atual().getY()+1 < numLinhas )
                if (lab[theWay.atual().getY()+1][theWay.atual().getX()].getState()>0)
                    s4 = lab[theWay.atual().getY()+1][theWay.atual().getX()].getState();
            else 
                s4 = 2000;
            
            
            
            if (theWay.atual().getX()-1 >= 0 )
                if (s1>0 && s1<=s2 && s1<=s3 && s1<=s4)
                    theWay.enqueueInicial(lab[theWay.atual().getY()][theWay.atual().getX()-1]);
            if (theWay.atual().getX()+1 < numLinhas)
                if (s2>0 && s2<=s1 && s2<=s3 && s2<=s4)
                    theWay.enqueueInicial(lab[theWay.atual().getY()][theWay.atual().getX()+1]);
            
            if (theWay.atual().getY()-1 >= 0)
                if (s3>0 && s3<=s2 && s3<=s1 && s3<=s4)
                    theWay.enqueueInicial(lab[theWay.atual().getY()-1][theWay.atual().getX()]);
            
            
            if (theWay.atual().getY()+1 < numLinhas )
                if (s4>0 && s4<=s2 && s4<=s3 && s4<=s1)
                    theWay.enqueueInicial(lab[theWay.atual().getY()+1][theWay.atual().getX()]);
            
            
            
            if (theWay.atual().getX()-1 >= 0 )
                if ( lab[theWay.atual().getY()][theWay.atual().getX()-1].getState() == -2)
                    break;
            if (theWay.atual().getX()+1 < numLinhas)
                if( lab[theWay.atual().getY()][theWay.atual().getX()-1].getState() == -2)
                    break;
            if (theWay.atual().getY()-1 >= 0 )
                if(lab[theWay.atual().getY()][theWay.atual().getX()-1].getState() == -2)
                    break;
            if (theWay.atual().getY()+1 < numLinhas )
                if(lab[theWay.atual().getY()][theWay.atual().getX()-1].getState() == -2)
                    break;
            
            theWay.dequeue();

            //printaCaminho(lab, numLinhas);
        }
        
        printaCaminho(lab, numLinhas);
        
    }
    //funcao para print da matriz
    public static void printa(Labirinto lab[][], int numLinhas){
        
        for (int i = 0; i < numLinhas; i++) {
            for (int j = 0; j < numLinhas; j++) {
                lab[i][j].print();
            }
            System.out.println("");
            
        }
        System.out.println("");
    }
    
    public static void printaCaminho(Labirinto lab[][], int numLinhas){
        
        for (int i = 0; i < numLinhas; i++) {
            for (int j = 0; j < numLinhas; j++) {
                lab[i][j].printTheWay();
            }
            System.out.println("");
            
        }
        System.out.println("");
    }
}
