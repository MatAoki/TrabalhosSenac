public class Fila{
    
    private Labirinto fila[];
    private int first;
    private int last;

    public Fila(Labirinto lab[][]) {
        
        this.fila = new Labirinto [100000];
        this.first = 0;
        this.last = 0;
    }
    
    public boolean isEmpty(){
        return this.first == this.last;
    }
    // insere na fila, ou seja, no final
    // somente pontos com state maior que 0
    public void enqueue( Labirinto ponto ){
        if (ponto.getState() >= 0){
            ponto.setState(ponto.getState()+1);
            this.fila[this.last++] = ponto;
        }
    }
    //insere na fila o ponto inicial
    public void enqueueInicial( Labirinto ponto ){
        this.fila[this.last++] = ponto;
        ponto.setCaminho(true);
    }
    
    public int size(){
        return this.last-this.first;
    }        
    public Labirinto dequeue(){
        return this.fila[this.first++];
    }
    
    public Labirinto atual(){
        return this.fila[this.first];
    }
    
    /*****************************************************************/
    //getters e setters
    public Labirinto[] getFila() {
        return fila;
    }

    public void setFila(Labirinto[] fila) {
        this.fila = fila;
    }

    public int getFirst() {
        return first;
    }

    public void setFirst(int first) {
        this.first = first;
    }

    public int getLast() {
        return last;
    }

    public void setLast(int last) {
        this.last = last;
    }
    
}
