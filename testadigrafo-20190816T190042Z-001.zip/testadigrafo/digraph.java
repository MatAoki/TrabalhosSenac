package testadigrafo;
/**
 *
 * @author fabio.aglubacheski
 */
public class digraph{
    private int V; // número de vértices
    private int A; // número de arcos
    private No adj[]; // listas de adjcências

    // construtor da clsse
    // inicializa os atributos da classe e cria a 
    // o vetor de listas deadjacências para V vértices
    public digraph( int V ){
        this.V = V+1;
        this.A = 0;
        this.adj = new No[this.V];
    }
    /* 
       Método insere um arco v-w no digrafo. O método supõe 
       que v e w são distintos, positivos e menores que V. 
       Se o digrafo já tem arco v-w, o método não faz nada.
       Insere aresta na lista de adjacencias no final
    */
    public void insereA( int v, int w){
        //System.out.println(v+" "+w);
        //Se o elemento for igual a ele mesmo, o metodo n faz nada
        if(v == w){
            System.out.println("Par "+ v +" "+w+" X deve ser diferente de Y"); 
            return;//ejeta
        }



        No aux = this.adj[v];
        No ant = null;
        while( aux != null ){

            //Se o digrafo já tem arco v-w, o método não faz nada
            if( aux.getElem() == w ){
                System.out.println("Par "+ v +" "+ w +" ja inserido");
                return; // ejeta
            }

            ant = aux;
            aux = aux.getProx();
        }

        if(ciclo(w,v)){
            System.out.println("Par "+ v +" "+w+" forma ciclo"); 
            return;//ejeta
        }

        No novo = new No( w, null );
        this.A++;// incrementa o numero de arcos
        // testa se a lista esta vazia
        if( ant == null ) // se lista vazia
            // joga no inicio da lista
            this.adj[v] = novo;
        else // insere no final da lista
            ant.setProx(novo);
    }
    /*
       Método remove do digrafo um arco aresta v-w. 
       O método supõe que v e w são distintos, positivos e 
       menores que V. Se não existe um arco v-w, método não 
       faz nada.
    */
    public void removeA( int v, int w){

        No aux = this.adj[v];
        No ant = null;
        while( aux != null ){
            //Se o digrafo for igual a ele mesmo, o metodo n faz nada
            if(v == w){
                System.out.println("Par "+ v +" "+w+" X deve ser diferente de Y"); 
                return;//ejeta
            }
            //Se o digrafo já tem arco v-w, remove
            if( aux.getElem() == w){
                this.A--;//reduz o numero de arcos
                if(ant == null)//verifica se esta no inicio da lista
                    this.adj[v] = aux.getProx();//pega o proximo para o inicio
                else
                    ant.setProx(aux.getProx());//faz o arco com o proximo depois do removido
            }

            ant = aux;
            aux = aux.getProx();
        }


    } 
    /*
       Para cada vértice v do grafo, este método imprime, em 
       uma linha, todos os vértices adjacentes a v. 
    */
    public void mostra( ){
        System.out.println("");
        for( int i=0;i<this.V;i++){
            System.out.print(i+": ");
            No aux = this.adj[i];
            while(aux != null){
              System.out.print(aux.getElem()+", ");
              aux = aux.getProx();
            }
            System.out.println();
        }
    }
    
    public void busca(){
        for (int v = 1; v < this.adj.length-1; v++) {
            this.adj[v].setVis(false);
        }
        for (int v = 1; v < this.adj.length-1; v++) {
            if(this.adj[v].getVis() == false){
                
                buscaProf(v);
                
                //CaminhosBombeiro(1, 6, "");
            }
        }
        System.out.println("");
        CaminhosBombeiro(1, 6, "");
    }

    public void buscaProf(int v){
        if(this.adj[v]==null){
            return;
        }
        this.adj[v].setVis(true);
        //System.out.println(v);

        No ant = null;
        No aux = this.adj[v];
        No prox = null;
        if (aux.getProx()!= null) {
            prox = aux.getProx();
        }


        while(aux != null){

            if(prox != null){
                if(this.adj[prox.getElem()].getVis() == false)
                    buscaProf(prox.getElem());
                else{
                    //System.out.println("ciclo");
                    return;
                }

            }

            ant = aux;
            aux = aux.getProx();
        }
    }

    public boolean ciclo(int inicio, int fim){
        for (int v = 1; v < this.adj.length; v++) {
            if(this.adj[v]!=null)
                this.adj[v].setVis(false);
        }

        buscaProf(inicio);

        if(this.adj[inicio]!=null && this.adj[fim]!=null){
            if(this.adj[inicio].getVis() == true && this.adj[fim].getVis() == true){
                return true;
            }
        }

        return false;
    }
    
    public void CaminhosBombeiro(int inicio, int fim, String resp) {
        resp = resp + " " + inicio;
        
        if(inicio == fim){
            System.out.println(resp);
            return;
        }
        
        No aux = this.adj[inicio];
        
        while(aux != null){
            CaminhosBombeiro(aux.getElem(), fim, resp);
            
            aux = aux.getProx();
        }
    }

    public No[] getAdj() {
        return adj;
    }

    public void setAdj(No[] adj) {
        this.adj = adj;
    }
}
