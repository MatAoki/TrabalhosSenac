public class Labirinto {
    //atributos
    private int x;
    private int y;
    private int state;
    private boolean caminho = false;
    
//state sao os passos para chegar ao objetivo
    public Labirinto(int y, int x, int state) {
        this.x = x;
        this.y = y;
        this.state = state;
    }
    
    public void print(){
        if (this.state == -2)
            System.out.print(" [a] ");
        else if (this.state == -3)
            System.out.print(" [b] ");
        else if (this.state == -1)
            System.out.print(" ["+this.state+"]");
        else
            System.out.print(" ["+this.state+"] ");
    }
    
    public void printTheWay(){
        if (this.state == -2)
            System.out.print(" [a] ");
        else if (this.state == -3)
            System.out.print(" [b] ");
        else if (this.state == -1)
            System.out.print(" ["+this.state+"]");
        else if (caminho == true)
            System.out.print(" [*] ");
        else
            System.out.print(" [0] ");
    }
    
    
    /*****************************************************************/
    //getters e setters
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getState() {
        return state;
    }

    public void setState(int state) {
        this.state = state;
    }
    
    public boolean isCaminho() {
        return caminho;
    }

    public void setCaminho(boolean caminho) {
        this.caminho = caminho;
    }
}
