/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coord;

/**
 *
 * @author Matheus
 */
public class Ponto {
    
    // atributos;
    private int x;
    private int y;
    double D;
    
    //definição de construtores...
    //ISSO NAO EH FUNCAO, EH CONSTRUTOR
    public Ponto(int X, int Y )
    {
       // corpo do construtor
       x = X;
       y = Y;
       
    }
    // métodos...
    public void setX(int x) {
        this.x = x;
    }
    public void setY(int y) {
        this.y = y;
    }
    
    public double calcDist(Ponto outra){
        double a = x;
        double b = y;
        double c = outra.x;
        double d = outra.y;
        
        D = Math.sqrt( (Math.pow((a-c), 2)+Math.pow((b-d), 2)) ); 
        
        //Ponto dist = new Ponto(a*c,b*d);
        return D;
        
    }
    public String getPonto(){
        return x+" "+y;
    }
    


    public void QuickSort( int v[], int p, int r)
    {
        if (p < r) {
            int j = particao(v, p, r );
            QuickSort(v, p, j-1);
            QuickSort(v, j+1, r);
        }
    }

    public int particao( int v[], int p, int r) 
    {
        int c, i, j;
        c = v[p];
        i = p+1;
        j = r;
        while (i <= j) {
            if (v[i] <= c)  
            i++; // sobe i
            else if ( v[j] > c )  
            j--; // desce j
            else{
            // troca
            int t = v[i]; v[i] = v[j]; v[j] = t; 
            i++; j--;
            }
        }
        // agora p == j+1
        v[p] = v[j]; v[j]=c;
        return j;
     
    }
  
 }
    

