/**
 *
 * @author matheus.maoki
 */
package bemformada;

public class Pilha {
    
        private char elementos[];
        private int topo;
        
        public Pilha(int tam) {
            this.elementos = new char[tam];
            this.topo = -1;
        }
        
        public void Push(char elemento){
            
            this.topo++;
            this.elementos[this.topo] = elemento;
        
        }
        
        public char Pop(){
            
            char elemento = this.elementos [this.topo];
            this.topo--;
            return elemento;
        }
        
        public boolean isEmpty(){
            if (this.topo == -1)
                return true;
            else 
                return false;
        
        }
}
